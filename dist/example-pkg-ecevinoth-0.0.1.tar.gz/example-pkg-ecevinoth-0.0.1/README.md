# Example Package - Learning PyPi

This is a simple example package.

Following are the few input arguments to setuptools.setup() function.

1. *name*
2. *version*
3. *author*
4. *author_email*
5. *description*
6. *long_description*
7. *long_description_content_type*
8. *url*
9. *packages*
10. *classifiers*


## useful links
[list of useful classifiers.](https://pypi.org/classifiers/)
[]
[help to choose license.](https://choosealicense.com/)
[For more markdown code.](https://guides.github.com/features/mastering-markdown/)